import userResolvers from '../resolvers/user';
import messageResolvers from '../resolvers/message';

export default [userResolvers, messageResolvers];